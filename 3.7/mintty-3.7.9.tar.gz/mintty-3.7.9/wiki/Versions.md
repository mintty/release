## Mintty versions and dependencies ##

#### Mintty release `3.7.9`

For tested compatibility with various Windows versions, see the 
[Compatibility table](http://mintty.github.io/#compatibility) on the 
mintty home page.

Built-in character information is based on Unicode `16.0.0`.
Unicode character width information is applicable when option 
`Charwidth` is set to anthing other than the default `locale`.

Compose key combinations are derived from the X11 library `1.8.10`.
