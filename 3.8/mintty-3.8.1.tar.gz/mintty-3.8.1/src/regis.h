extern void regis_clear(HDC dc, int w, int h);
extern void regis_home(void);
extern void regis_draw(HDC dc, int w, int h, int mode, uchar * regis);

